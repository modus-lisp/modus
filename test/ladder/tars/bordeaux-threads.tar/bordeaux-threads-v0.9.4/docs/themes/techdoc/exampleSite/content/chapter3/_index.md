---
title: "Chapter 3 (hierarchized)"
date: 2017-10-17T15:26:15Z
draft: false
weight: 40
---

{{% panel status="primary" title="Note" icon="far fa-lightbulb" %}}
The document hierarchy is unlimite.
{{% /panel %}}

Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
